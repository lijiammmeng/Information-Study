
popsize=20;
MAXITER=2000;
dimension=30;
irange_l=15;
irange_r=30;
xmax=100;
vmax=100;

c1=2;
c2=2;


sum1=0;
for run=1:50

x=(irange_r- irange_l)*rand(popsize,dimension) + irange_l;
v=2*vmax*rand(popsize,dimension)-vmax;


pbest=x;



for i=1:popsize
    f_x(i)=f2(x(i,:));
    f_pbest(i)=f_x(i);
end
   
   
    g=min(find(f_pbest==min(f_pbest(1:popsize))));
    gbest=pbest(g,:);
   
 


MINIUM=f_pbest(g);
for t=0:MAXITER
    a=(0.9-0.4)*(MAXITER-t)/MAXITER+0.4;
    for i=1:popsize   
         for d=1:dimension
             v(i,d)=a*v(i,d)+2*rand(1,1)*(pbest(i,d)-x(i,d))+2*rand(1,1)*(gbest(d)-x(i,d));
             if v(i,d)>vmax
                v(i,d)=vmax;
            end
            if v(i,d)<-vmax
                v(i,d)=-vmax;
            end
            x(i,d)=x(i,d)+v(i,d);
%             if x(i,d)>xmax
%                x(i,d)=xmax;
%             end
        end
        f_x(i)=f2(x(i,:));
        if f_x(i)<f_pbest(i)
           pbest(i,:)=x(i,:);
           f_pbest(i)=f_x(i);
        end
            
        g=min(find(f_pbest==min(f_pbest(1:popsize))));
        gbest=pbest(g,:);
            
            
        if f_pbest(g)<MINIUM
            MINIUM=f_pbest(g);
        end
    end
    MINIUM
end
sum1=sum1+MINIUM;
end
av=sum1/50;
        
 